<?php include_once("hf/header.php"); 
require("php/class/conexao.php");
if(!isset($_SESSION["nivelAcesso"]) == "Admin"){
  header("location:login.php");
}
?>
<!-- fim header -->


<main>

  <section class="admin">

    <aside>

      <ol>
        <li class="fas fa-edit"> <a href="admin.php">INSERIR PRODUTOS</a></li>
        <li class="far fa-user active"> <a href="client.php">VER CLIENTE</a></li>
        <li class="fal fa-shopping-cart"> <a href="compra.php">VER COMPRA</a></li>
      </ol>

    </aside>


    <section class="cart-table">
      <table>



        <thead>
          <tr>

            <th colspan="3" class="search-header">
              <form>
              <div class="form" action="">
                <input type="search" name="searchcliente" placeholder="Pesquisar..."> <button><i class="far fa-search"></i></button>
              </div class="form">
              </form>
            </th>

          </tr>
          <tr>

            <th>NOME</th>
            <th>SOBRE-NOME</th>
            <th>EMAIL</th>
            
          </tr>
        </thead>
        <tbody>
        </tbody>
		
      </table>
    </section>
	<script>
	//Exibir clientes na tabela
	let time = setInterval(()=>{
		
					let xml = new XMLHttpRequest();
					xml.open(`get`, `php/tabelas.php?cliente=cliente`, true);
						
					xml.onreadystatechange = () => {
						if(xml.readyState === XMLHttpRequest.DONE && xml.status === 200){
							let resposta = xml.response;
							
							document.querySelector("tbody").innerHTML=resposta;
							time;
					
						}
					}		
						
					xml.send();
				},1000);
				
	//pesquisar clientes na tabela//pesquisar productos;
			let search = document.querySelector(".search-header form"),
			searchbtn = search.querySelector(".search-header input");

			  search.addEventListener("submit", (e) => {
				e.preventDefault();
				
			  });

			  searchbtn.addEventListener("keyup", () => {
				let xml = new XMLHttpRequest();
				clearInterval(time);
				xml.open("post", "php/crudAdmin.php", true);

				xml.onreadystatechange = () => {
				  if (xml.readyState == XMLHttpRequest.DONE && xml.status == 200) {
					let resposta = xml.response;
					document.querySelector(".cart-table tbody").innerHTML = resposta;
				  }
				}

				let formData = new FormData(search);
				xml.send(formData);
			  });
	</script>
  </section>

</main>
<script src="js/script.js"></script>


</script>
</body>

</html>