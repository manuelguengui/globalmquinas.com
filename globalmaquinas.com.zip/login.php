<?php include("hf/headerSign.php") ?>

<!-- fim header -->

<h2 class="h2form">Entrar</h2>
<main class="form-sign login">
  <form>
    <div class="mobile-alert">
      <p class="erro"></p>
    </div>
    <div class="email">

      <input type="text" name="email" autofocus class="input-feild" id="email" placeholder="E-mail" required>
    </div>
    <div class="password">
      <input type="password" name="senha" class="input-feild" id="password" placeholder="Palavra-passe" required>
      <i class="fas fa-eye"></i>
    </div>
    <div class="alert-mb">
      <p id="erro-mb"></p>
    </div>
    <div class="btn">

      <input type="submit" value="Entrar" id="entrar" class="btn-entrar">
    </div>
    <p>Ainda não tens conta? <a href="signup.php">Cadastrar-se</a></p>
  </form>
</main>


<script src="js/script.js"></script>
<script>
    const signup = document.querySelector(".login form"),
    entrar = signup.querySelector(".btn input");

signup.onsubmit = (e) => {
  e.preventDefault();
}

entrar.onclick = () => {
  let xml = new XMLHttpRequest();
  xml.open("POST", "php/logar.php", true);

  xml.onreadystatechange = () => {
    if(xml.readyState === XMLHttpRequest.DONE && xml.status === 200){
      let resposta = xml.response;

      if(resposta =="sucesso") {
        location.href="index.php";
      }else {
        let = erroMb = document.getElementById("erro-mb");
        let = erroDk = document.getElementById("erro-dk");

        erroDk.classList.add("active");
        erroDk.innerText = resposta;

        erroMb.classList.add("active");
        erroMb.innerText = resposta;

      }
    }
  }

    let formData = new FormData(signup)
  xml.send(formData);
}




  </script>
</body>

</html>