<?php include_once("hf/header.php");


?>

<!-- fim header -->
<main>
  <div class="cart-row">

    <section class="cart-table">
      <table>
        <thead>
          <tr>
            <th>REMOVER</th>
            <th>PRODUCTOS</th>
            <th>MARCA</th>
            <th>PREÇO</th>
            <th>QUANTIDADE</th>
          </tr>
        </thead>
        <tbody>


        </tbody>
        <tfoot>
          <tr>
            <td>Total</td>
            <td colspan="4" id="custo"></td>
          </tr>
        </tfoot>
      </table>
    </section>

    <script>
      //Exibição dos productos na tela
      setInterval(() => {

        let xml = new XMLHttpRequest();
        xml.open(`get`, `php/tabelas.php?cart=exibir-p`, true);

        xml.onreadystatechange = () => {
          if (xml.readyState === XMLHttpRequest.DONE && xml.status === 200) {
            let resposta = xml.response;

            document.querySelector("tbody").innerHTML = resposta;

          }
        }

        xml.send();
      }, 1000);

      //exibir o total da venda a pagar
      setInterval(() => {
        let xml = new XMLHttpRequest();
        xml.open("get", "php/crudClient.php?custo=custo", true);
        xml.onreadystatechange = () => {
          if (xml.status == 200 && xml.readyState === XMLHttpRequest.DONE) {
            let resposta = xml.response;

            document.querySelector("#custo").textContent = resposta;
          }
        }
        xml.send();
      }, 1000)


      //Actualizar carrinho 
      function actualizar(id, user) {
        let input = document.querySelector('.cart-row input[type="number"]').value;


        let xml = new XMLHttpRequest();
        xml.open("get", `php/crudClient.php?id=${id}&user=${user}&valor=${input}`, true);

        xml.onreadystatechange = () => {
          if (xml.readyState === XMLHttpRequest.DONE && xml.status === 200) {
            let resposta = xml.response;

          }
        }

        xml.send();
      }

      //Eliminar producto no carrinho
      function remover(id, user) {


        let xml = new XMLHttpRequest();
        xml.open("get", `php/crudClient.php?remover=${id}&user=${user}`, true);

        xml.onreadystatechange = () => {
          if (xml.readyState === XMLHttpRequest.DONE && xml.status === 200) {
            let resposta = xml.response;
            if (resposta == "sucesso") {

            }
          }
        }

        xml.send();
      }
    </script>

    <section class="buynow">
      <form>

        <div class="input-col col">
          <input class="input-field" type="text" require  d name="nome" placeholder="Teu nome" value="<?= isset($_SESSION["id"]) ? $_SESSION["nome"] . " " . $_SESSION["snome"] : ""; ?>">
          <input class="input-field" type="email" required name="email" placeholder="E-mail" value="<?= isset($_SESSION["id"]) ? $_SESSION["email"] : ""; ?>">

          <input class="input-field clean" type="text" name="endereco" required placeholder="Endereço">
        </div>
		<div class="paycard-col">
          <img src="img/logo-bai.svg" width="90px" height="37px">
          <img src="img/atlantico.png" width="90px" height="37px">
          <img src="img/sol.png" width="90px" height="37px">
        </div>
        
        <div class="paycheck col">
          <label for="pagamento"><input type="checkbox" name="pagamento" value="Pagamento na Emtrega" id="pagamento"> Pagamento na Entrega</label>
        </div>


        <div class="btn-pay col">
          <div class="alert-mb">
            <p id="erro-mb"></p>
          </div>
          <button <?= !isset($_SESSION["id"]) ? "disabled" : ""; ?>>Comprar</button>
        </div>
      </form>
    </section>

  </div>
  <!-- efectuar compra -->
  <script>
    let form = document.querySelector(".buynow form"),
      btn = form.querySelector(".buynow form button");
    form.addEventListener("submit", (e) => {
      e.preventDefault();
    })
    btn.addEventListener("click", () => {

      let xml = new XMLHttpRequest();
      xml.open("post", "php/crudClient.php", true);

      xml.onreadystatechange = () => {
        if (xml.status == 200 && xml.readyState === XMLHttpRequest.DONE) {
          let resposta = xml.response;
          console.log(resposta)
          if (resposta == "Sucesso") {
            for (let i = 0; i < document.getElementsByClassName("clean").length; i++) {
                document.getElementsByClassName("clean")[i].value = "";
              }
            window.location.href="relatorio.php";
          } else {
            let = erroMb = document.getElementById("erro-mb");
            let = erroDk = document.getElementById("erro-dk");

            erroDk.classList.add("active");
            erroDk.innerText = resposta;

            erroMb.classList.add("active");
            erroMb.innerText = resposta;
          }

        }
      }

      let formDados = new FormData(form);
      xml.send(formDados);
    })
  </script>



  <!-- footer -->
  <?php include_once("hf/footer.php") ?>