<?php include_once("hf/header.php");
require("php/class/conexao.php");
$conexao = new CONEXAO();
$conexao = $conexao->conectar();

if(empty($_GET)){
	header("location:index.php");
}

?>

  <!-- fim header -->

  <main>

    <article class="prodetails">
	
	<?php 
	
		$sql = "SELECT * FROM producto WHERE id =".$_GET["produto"];
		$stmt = $conexao->prepare($sql);
		$stmt->execute();
		$row = $stmt->fetch();
		?>
	 
      <section class="pro-image">
        <figure class="apresentation">
          <img src="productos/<?=$row["img"]?>" width="100%" id="main-img">
        </figure>
      </section>
      <section class="product-info">
        <strong>PRODUCTO: <?=$row["producto"];?> / <?=$row["marca"];?></strong> <br>
        <strong>PREÇO: <?=number_format($row["preco"], 2, ",", ".")?></strong><br><br>
        <strong>DESCRIÇÃO:</strong>
        <p><?=$row["descricao"];?></p>
        <div class="field">
          <input type="number" name="" id="" value="<?=$row["quantidade"]; ?>" disabled>
          <button onclick="addCart(<?= $row["id"] . ',' .$_SESSION["id"] ?>)">Add to Cart</button>
        </div>
      </section>
	
    </article>

    <section id="product1" class="section-p1">
      <h2>Produtos variados</h2>
      <p>Faça a tua Compra na Global Máquinas</p>
  
      <div class="pro-conteiner" >
      
      </div>
    </section>
 <script>
  setInterval(()=>{
		
		let xml = new XMLHttpRequest();
		xml.open(`get`, `php/productos.php?producto=f-producto`, true);
			
		xml.onreadystatechange = () => {
			if(xml.readyState === XMLHttpRequest.DONE && xml.status === 200){
				let resposta = xml.response;
				
				document.querySelector(".pro-conteiner").innerHTML=resposta;
		
			}
		}		
			
		xml.send();
	},4000);
	
	
	</script>




    <!-- footer -->
    <?php include_once("hf/footer.php")?>
