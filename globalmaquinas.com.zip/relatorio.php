<?php
session_start();
require("php/class/conexao.php");
$conexao = new CONEXAO();
$conexao = $conexao->conectar();
if(!(isset($_SESSION["id"]) && ($_SESSION["nivelAcesso"]!="Admin"))){
    header("location:login.php");
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório da Compra</title>
    <link rel="stylesheet" href="css/relatorio.css">
</head>

<body>

    <main id="factura">
        <header>
        <h1><a href="cart.php"><img src="img/logo.png" width="250"></a></h1>

        </header>
        <br>
        <div class="column-1">
            <section class="info-empresa">
                <strong>GLOBALMÁQUINAS-EQUIPAMENTO INDUSTRIAIS, LDA</strong>
                <P>Contribuinte N.°: 547247073</P>
                <p>Rua do Dream Space, Kikuxi-Viana-Luanda</p>
                <p>Telef: +244 942 520 043 Fax +244 945 166 741</p>
                <p>Capital Social 1 950 000,00 AKZ</p>
                <P>Cons. Reg. Com. 2°SECÇÃOGUICHEUNICO</P>
                <P>Matricula N.° 3355-131018</P>
                <p>globalmaquinas6@gmail.com</p>
                <p>www.globalmaquinas.com</p>
                <p><b>ATLANTICO:</b>0055.0000.4699.6375.1013.1</p>
                <p><b>BAI:</b>0040.0000.5883.2566.1013.0</p>
                <p><b>SOL:</b>0044.0000.0435.4250.1018.5</p>
            </section>
            <section class="cliente">
                <?php
                $sql = "SELECT * FROM user WHERE id = :userId";
                $stmt = $conexao->prepare($sql);
                $stmt->bindValue(":userId", (int)$_SESSION["id"]);
                $stmt->execute();

                $row = $stmt->fetch();
                $row["p_nome"];
				$timestampAtual = time();
					$dias = rand(7, 14);
					$timestampFuturo = $timestampAtual + ($dias * 24 * 60 * 60);

					$dataFutura = date('d-m-Y', $timestampFuturo);

					


                ?>
                <p>Exmo.(s) Sr.(s)</p>
                <p class="nome"><?= $row["p_nome"] . " " . $row["s_nome"] ?></p>
                <p>Endereço cliente</p>
            </section>
        </div>
        <h4>Guia de Remessa GR GT. data</h4>

        <div class="column-2">
            <!-- primeira tabela de informação -->
            <div class="column-2-1">
                <table class="first-table tabela">
                    <tr>
                        <th>V/N.°Contrib</th>
                        <th>Requisição</th>
                        <th>Moeda</th>
                        <th>Câmbio</th>
                        <th>Data</th>
                        <th>Prazo de Entrega</th>
                    </tr>
                    <tr>
                        <td>00796990BE036</td>
                        <td></td>
                        <td>AKZ</td>
                        <td>1,00</td>
                        <td><?= date("d-m-Y") ?></td>
                        <td><?= $dataFutura ?></td>
                    </tr>
                </table>
                <!-- segunda tabeta de informação -->
                <table class="second-table tabela">
                    <tr>
                        <th>Desc. cli</th>
                        <th>Desc.Fin</th>
                        <th>Vencimento</th>
						<th>Prazo de Entrega</th>
                        <th>Condição de Pagamento</th>
                    </tr>
                    <tr>
                        <td>0,00</td>
                        <td>0,00</td>
                        <td><?= date("d-m-Y") ?></td>
						<td><?= $dataFutura ?></td>
                        <td>Pagamento na Entrega <input type="checkbox"></td>
                    </tr>
                </table>
            </div>
            <!-- tabela de dados de compras -->
            <table class="third-table tabela">
                <tr>
                    <th>Artigo</th>
                    <th class="descricao">Descrição</th>
                    <th>Qtd</th>
                    <th>Pr. Unitário</th>
                    <th>Desc.</th>
                    <th>IVA</th>
                </tr>
                <?php
                $sql2 = "SELECT * FROM carrinho WHERE id_user=:userId";
                $stmt = $conexao->prepare($sql2);
                $stmt->bindValue(":userId", (int)$_SESSION["id"]);
                $stmt->execute();
                foreach ($stmt->fetchAll() as $row) {

                ?>
                    <tr>
                        <td><?= $row["producto"] ?></td>
                        <td><?= $row["descricao"] ?></< /td>
                        <td><?= $row["quantidade"] ?></< /td>
                        <td><?= number_format($row["preco"], 2, ",", ".") ?></< /td>
                        <td>0,00</td>
                        <td>14,00</td>
                    </tr>
                <?php } ?>
            </table>
        </div>

        <div class="column-3">
            <strong>Quadro Resumo de imposto(IVA incluido à taxa)</strong>
            <table class="fourth-table tabela">
                <tr>
                    <th>Taxa/valor</th>
                    <th>Incid./Qtd.</th>
                    <th>Total</th>
                    <th>Motivo Isenção</th>
                </tr>
                <tr>
                    <td>IVA (14, 00)</td>
                    <td>0,00</td>
                    <td>1000.00</td>
                </tr>
            </table>
            <div class="column-3-1">
                <div class="cloumn-3-1-1">
                    <table class="five-table">
                        <tr>
                            <th>Carga</th>
                            <th>Descraga</th>
                        </tr>
                        <tr>
                            <td>ARMAZEM DE VIANA - ESTALEIRO GLOBALMA <br>
                                Cenro de Negócio "ACCP" Rua António assis <br>
                                777 - ESC 105 Luanda</td>

                            <td>RESTAURANTE SALPICO NA GRELHA - 2015 <br>
                                Kikuxi-Viana-Luanda-Angola</td>
                        </tr>

                    </table>
                    <table class="total">
                        <?php
                        $sql = "SELECT SUM(preco * quantidade) AS total FROM carrinho WHERE id_user = :userId";
                        $stmt = $conexao->prepare($sql);
                        $stmt->bindValue("userId", (int)$_SESSION["id"]);
                        $stmt->execute();
                        $row = $stmt->fetch();

                       ;
                        ?>
                        <tr>
                            <th>Total (AKZ)</th>
                            <th><?= number_format( $row["total"], 2, ",", ".") . "Kz"?></th>
                        </tr>

                    </table>
                </div>
            </div>
        </div>
                
                <?php
                 $sql2 = "DELETE FROM carrinho WHERE id_user = :userId";
                 $stmt = $conexao->prepare($sql2);
                 $stmt->bindValue(":userId", (int)$_SESSION["id"]);
                 $stmt->execute();
                
                
                
                ?>
				<script>
                    window.print();
                    
                </script>

    </main>
</body>

</html>