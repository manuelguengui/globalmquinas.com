<?php include_once("hf/header.php");


 ?>


<!-- fim header -->

<main>
  <section id="hero">
    <h3>Vendemos Máquinas de vários tipos</h3>
    <p>Satisfazer os nossos clientes e o nosso comprimisso</p>
    
    <button class="normal" onclick="location.href='products.php'">Comprar Agora</button>
  </section>
  <section class="section-p1" id="feature">
    <figure class="fe-box">
      <img src="img/f1.png" alt="">
      <h6>Transporte Grátis</h6>
    </figure>
    <figure class="fe-box">
      <img src="img/f2.png" alt="">
      <h6>Pedido On-line</h6>
    </figure>
    <figure class="fe-box">
      <img src="img/f3.png" alt="">
      <h6>Pagamento Seguro</h6>
    </figure>
    <figure class="fe-box">
      <img src="img/f4.png" alt="">
      <h6>Promoção</h6>
    </figure>
    <figure class="fe-box">
      <img src="img/f5.png" alt="">
      <h6>Promove Felicidade</h6>
    </figure>
    <figure class="fe-box">
      <img src="img/f6.png" alt="">
      <h6>F24/7 Suporte</h6>
    </figure>
  </section>

  <section id="banner" class="section-m1">
    <h4>Promoção</h4>
    <h2>Acima de 5 Máquinas, recebe desconto de <span>15% Off</span> e Alguns acessório</h2>
    <button class="normal">Explore + </button>
  </section>

  <section id="product1" class="section-p1">
    <h3>Máquinas de varios tipos</h3>
    <p>Máquinas e ferramentas Industriais</p>

    <div class="pro-conteiner">
    
	

    </div>
	
	<script>
	setInterval(()=>{
		
		let xml = new XMLHttpRequest();
		xml.open(`get`, `php/productos.php?producto=index`, true);
			
		xml.onreadystatechange = () => {
			if(xml.readyState === XMLHttpRequest.DONE && xml.status === 200){
				let resposta = xml.response;
				
				document.querySelector(".pro-conteiner").innerHTML=resposta;
		
			}
		}		
			
		xml.send();
	},4000);
	
	
	</script>
	
  </section>
  

  <section id="sm-banner" class="section-p1">
    <div class="banner-box banner-box-1">
      <h4>Temos Suportes</h4>
      <h2>Equipa preparada para lhe a judar </h2>
      <span>Primeira manutenção por nossa conta</span>
      <button class="white">Saber mais</button>
    </div>

    <div class="banner-box banner-box-2">
      <h4>Transportamos</h4>
      <h2>Trasporte para nossas percadorias</h2>
      <span>Transportamos os nossos produtos para qualquer parte do território Nacional Angolano</span>
      <button class="white">Saber mais</button>
    </div>
  </section>
  
  <!-- footer -->
  <?php include_once("hf/footer.php") ?>