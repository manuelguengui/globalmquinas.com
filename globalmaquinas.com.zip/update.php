<?php 
session_start();
include("hf/headerSign.php");
if(empty($_GET["id"]) && (isset($_SESSION["nivelAcesso"]) != "Admin")){
    header("location:login.php");
} 

require("php/class/conexao.php");
require("php/class/admin.php");
$conexao = new CONEXAO();

$sql = "SELECT * FROM producto WHERE id =".$_GET["id"];
$stmt = $conexao->conectar()->prepare($sql);
$stmt->execute();

$row = $stmt->fetch();

?>
<!-- fim header -->

<main class="update">
    <form>
	<input required hidden type="number" name="id" value="<?= isset($_GET["id"])?  $_GET["id"]:""; ?>" class="clean">
    <div class="first comun">
        
            <input required type="text" placeholder="Producto" name="producto" class="clean" value="<?= $row["producto"] ?>">
            
            
            <input required type="text" placeholder="Marca" name="marca" class="clean"  value="<?= $row["marca"] ?>">
          </div>
          <div class="second comun">
          
            <input required type="number" placeholder="Preço" name="preco" class="clean" value="<?= $row["preco"] ?>">
           
            <input required type="number" placeholder="Quantidade" name="qtd" class="clean" value="<?= $row["quantidade"]?>">
          </div>

          <div class="third">
            <textarea required name="dscr" placeholder="Descrição do producto" class="clean" cols="20" rows="5" placeholder="Descrição do producto"><?= $row["descricao"]?></textarea>

            
              <button class="btnactualizar">Aclualizar</button>

              <div class="alert-mb">
                <p id="erro-mb"></p>
              </div>
</form>
</main>
<script>
    let form = document.querySelector("form"),
    btnactualizar = form.querySelector("form button");
    form.addEventListener("submit", (e)=>{
        e.preventDefault();
    })

    btnactualizar.addEventListener("click", ()=>{
        let xml = new XMLHttpRequest();
        xml.open("post", "php/crudAdmin.php", true);
        
        xml.onreadystatechange = ()=>{
            if(xml.status == 200 && xml.readyState == XMLHttpRequest.DONE){
                let resposta = xml.response;
                if(resposta == "Sucesso"){
                    window.location.href="admin.php";
                }else {
                    let = erroMb = document.getElementById("erro-mb");
                    let = erroDk = document.getElementById("erro-dk");

                    erroDk.classList.add("active");
                    erroDk.innerText = resposta;

                    erroMb.classList.add("active");
                    erroMb.innerText = resposta;
                }
                
            }
        }

        let formDados = new FormData(form);
        xml.send(formDados);
    })
</script>
</body>

</html>