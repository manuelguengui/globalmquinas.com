<?php include_once("hf/header.php");
require("php/class/conexao.php");
$conexao = new CONEXAO();
$conexao = $conexao->conectar();
if(!isset($_SESSION["nivelAcesso"]) == "Admin"){
  header("location:login.php");
}
?>

<!-- fim header -->


<main>

  <section class="admin">

    <aside>

      <ol>
        <li class="fas fa-edit"> <a href="admin.php">INSERIR PRODUTOS</a></li>
        <li class="far fa-user"> <a href="client.php">VER CLIENTE</a></li>
        <li class="fal fa-shopping-cart active"> <a href="compra.php">VER COMPRA</a></li>
      </ol>

    </aside>


    <section class="cart-table">
      <table>



        <thead>
          <tr>

            <th colspan="6" class="search-header">
              <form>
                <div class="form" action="">
                  <input type="search" name="searchCompra" placeholder="Pesquisar..."> <button><i class="far fa-search"></i></button>
                </div class="form">
              </form>
            </th>

          </tr>
          <tr class="compra">

            <th>EMAIL</th>
            <th>ENDEREÇO</th>
            <th>PRODUCTO</th>
            <th>TIPE-PAGAMENTO</th>
            <th>PAGAMENTO</th>
            <th>DATA</th>
			<th>ENTREGA</th>
          </tr>
        </thead>
        <tbody>
		
		
      </table>
    </section>
  </section>
      <script>
	//Exibir compra dos clientes na tabela admin

        let time = setInterval(()=>{
		
        let xml = new XMLHttpRequest();
        xml.open(`get`, `php/tabelas.php?compra=compra`, true);
          
        xml.onreadystatechange = () => {
          if(xml.readyState === XMLHttpRequest.DONE && xml.status === 200){
            let resposta = xml.response;
            
            document.querySelector("tbody").innerHTML=resposta;
            time;
        
          }
        }		
      
    xml.send();
  },1000);

  	
	//pesquisar cliente que efectuaram compra;
  let search = document.querySelector(".search-header form"),
			searchbtn = search.querySelector(".search-header input");

			  search.addEventListener("submit", (e) => {
				e.preventDefault();
				
			  });

			  searchbtn.addEventListener("keyup", () => {
				let xml = new XMLHttpRequest();
				clearInterval(time);
				xml.open("post", "php/crudAdmin.php", true);

				xml.onreadystatechange = () => {
				  if (xml.readyState == XMLHttpRequest.DONE && xml.status == 200) {
					let resposta = xml.response;
					document.querySelector(".cart-table tbody").innerHTML = resposta;
				  }
				}

				let formData = new FormData(search);
				xml.send(formData);
			  });
			  //marca como realizada
			   function realizar(id) {
				  let xml = new XMLHttpRequest();

				  xml.open("get", "php/crudAdmin.php?realizar=" + id, true);
				  xml.onreadystatechange = () => {
					if (xml.status == 200 && xml.readyState == XMLHttpRequest.DONE) {
					  let responsta = xml.response;

					}

				  }
				  xml.send();
				}
      </script>
</main>
<script src="js/script.js"></script>

</body>

</html>