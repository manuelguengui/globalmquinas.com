<?php include_once("hf/header.php");
include_once("php/class/conexao.php");
$conexao = new CONEXAO();
if (!isset($_SESSION["nivelAcesso"]) == "Admin") {
  header("location:login.php");
}
?>

<!-- fim header -->
<main>
  <section class="admin-insert">
    <div>
      <form class="form-insert" enctype="multipart/form-data">

        <div class="conteiner">
          <section class="close">
            <i class="fas fa-times times"></i>
          </section>

          <div class="first comun">
            <input required type="text" name="producto" class="clean" placeholder="Producto">
            <input required type="text" name="marca" class="clean" placeholder="Marca">
          </div>
          <div class="second comun">
            <input required type="number" name="preco" class="clean" placeholder="Preço">
            <input required type="number" name="qtd" class="clean" placeholder="Quantidade">
          </div>
          <input type="file" name="img" class="clean">

          <div class="third">
            <textarea required name="dscr" class="clean" cols="20" rows="5" placeholder="Descrição do producto"></textarea>


            <button class="btnInserir">Salvar</button>






          </div>
        </div>
        <div class="alert-mb">
          <p id="erro-mb"></p>
        </div>
      </form>
    </div>
    <script>
      //inserir producto
      let form = document.querySelector(".admin-insert .form-insert"),
        btnSave = form.querySelector(".admin-insert .form-insert .btnInserir");

      form.addEventListener("submit", (e) => {
        e.preventDefault();

      })

      btnSave.onclick = () => {
        let xml = new XMLHttpRequest();

        xml.open("post", "php/insert.php", true);
        xml.onreadystatechange = () => {
          if (xml.readyState === XMLHttpRequest.DONE && xml.status == 200) {
            let resposta = xml.response;
            let = erroMb = document.getElementById("erro-mb");
            let = erroDk = document.getElementById("erro-dk");
            console.log(resposta);
            if (resposta == "Sucesso") {
              for (let i = 0; i < document.getElementsByClassName("clean").length; i++) {
                document.getElementsByClassName("clean")[i].value = "";
              }

              erroDk.classList.remove("active");
              erroMb.classList.remove("active");
            } else {
              

              erroDk.classList.add("active");
              erroDk.innerText = resposta;

              erroMb.classList.add("active");
              erroMb.innerText = resposta;
            }
          }
        }
        let formData = new FormData(form);
        xml.send(formData);
      }
    </script>
  </section>
  <section class="admin">

    <aside>

      <ol>
        <li class="fas fa-edit insert"> <a href="#">INSERIR PRODUTOS</a></li>
        <li class="far fa-user"> <a href="client.php">VER CLIENTE</a></li>
        <li class="fal fa-shopping-cart"> <a href="compra.php">VER COMPRA</a></li>
      </ol>

    </aside>


    <section class="cart-table">
      <table>



        <thead>
          <tr>

            <th colspan="6" class="search-header">
              <div class="form">
                <form>
                  <input type="search" name="searchproducto" placeholder="Producto ou descrição"> <button><i class="far fa-search"></i></button>
                </form>
              </div class="form">
            </th>

          </tr>
          <tr>

            <th>PRODUCTOS</th>
            <th>MARCA</th>
            <th>PREÇO</th>
            <th>QUANTIDADE</th>
            <th>DESCRIÇÃO</th>
            <th>ACÇÃO</th>
          </tr>
        </thead>
        <tbody>





      </table>
    </section>
  </section>
  <script>
    //apagar producto
    function apagar(d) {
      let xml = new XMLHttpRequest();

      xml.open("get", "php/crudAdmin.php?apagar=" + d, true);
      xml.onreadystatechange = () => {
        if (xml.status == 200 && xml.readyState == XMLHttpRequest.DONE) {
          let responsta = xml.response;

        }

      }
      xml.send();
    }

    //exibição dos prodotos na tela;
    let time = setInterval(() => {

      let xml = new XMLHttpRequest();
      xml.open(`get`, `php/tabelas.php?admin=admin`, true);

      xml.onreadystatechange = () => {
        if (xml.readyState === XMLHttpRequest.DONE && xml.status === 200) {
          let resposta = xml.response;
          document.querySelector("tbody").innerHTML = resposta;
          time;

        }
      }

      xml.send();
    }, 1000);



    //pesquisar productos;
    let search = document.querySelector(".search-header form"),
      searchbtn = search.querySelector(".search-header input");

    search.addEventListener("submit", (e) => {
      e.preventDefault();

    });

    searchbtn.addEventListener("keyup", () => {
      let xml = new XMLHttpRequest();
      clearInterval(time);
      xml.open("post", "php/crudAdmin.php", true);

      xml.onreadystatechange = () => {
        if (xml.readyState == XMLHttpRequest.DONE && xml.status == 200) {
          let resposta = xml.response;
          document.querySelector(".cart-table tbody").innerHTML = resposta;
        }
      }

      let formData = new FormData(search);
      xml.send(formData);
    });
  </script>

</main>
<script src="js/script.js"></script>



</body>

</html>