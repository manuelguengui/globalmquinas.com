<?php include_once("hf/header.php");

?>
 
  <!-- fim header -->

  <main>
   
	
    <section class="contact">
      <h2>Nossos contactos</h2>
    </section>

    <section class="contact-deteil">
      <div class="contact-info">
        <h4>Conecta-se a nós</h4>
      <p>Visita a nossa empresa ou entre em contacto connosco ainda hoje</p>
      <ul>
        <li><a href="mailto://globalmaquinas6@gmail.com" class="far fa-envelope"></a> globalmaquinas6@gmail.com</li>
        <li><a href="" class="fas fa-phone-alt"></a>(+244) 948 451 449 / (+244) 945 627 088</li>
        <li><a href="#" class="far fa-clock"></a>08:00 - 17:30, Mon - Fr</li>
        <li><a href="#" class="far fa-clock"></a>08:00 - 12:00, Sat</li>
      </ul>
      </div>
      <div class="google-map">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3941.0695532153713!2d13.377752375210365!3d-8.965738692210572!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1a51f53789aa46af%3A0x9589575353618af0!2sGLOBALMAQUINAS%20LDA!5e0!3m2!1spt-PT!2sao!4v1710692314609!5m2!1spt-PT!2sao" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>
    </section>

    <section class="email-contact">
      <form>
        <input type="text" name="emailFrom" hidden placeholder="Teunome" value="<?= isset($_SESSION["email"])? $_SESSION["email"]: ""; ?>">
        <input type="text" name="nome" hidden placeholder="Teunome" value="<?= isset($_SESSION["nome"])? $_SESSION["nome"]: ""; ?>">
        <input type="text" name="snome" hidden placeholder="Teunome" value="<?= isset($_SESSION["snome"])? $_SESSION["snome"]: ""; ?>">
		<input type="email" placeholder="E-mail" value="globalmaquinas6@gmail.com" disabled>
        <input type="text" name="assunto" placeholder="Assunto" <?= (isset($_SESSION["nivelAcesso"]) && $_SESSION["nivelAcesso"] == "Admin")? "disabled": ""; ?>>
        <textarea name="sms" id="sms" cols="30" rows="10" placeholder="Escreva aqui..." <?= (isset($_SESSION["nivelAcesso"]) && $_SESSION["nivelAcesso"] == "Admin")? "disabled": ""; ?>></textarea>
        <button><i class="far fa-paper-plane" <?= (isset($_SESSION["nivelAcesso"]) && $_SESSION["nivelAcesso"] == "Admin" )? "disabled": ""; ?>></i></button>
      </form>
    </section>
	<script>
	const mensagem = document.querySelector(".email-contact form"),
	enviar = mensagem.querySelector("form button");

	mensagem.onsubmit = (e) => {
		e.preventDefault();
	}

	enviar.onclick = () => {
	let xml = new XMLHttpRequest();
	xml.open("POST", "php/mensagem.php", true);

	xml.onreadystatechange = () => {
    if(xml.readyState === XMLHttpRequest.DONE && xml.status === 200){
      let resposta = xml.response;
        
      if(resposta =="Sucesso") {
        
          window.location.href="index.php";
        
      }else {
        let = erroMb = document.getElementById("erro-mb");
        let = erroDk = document.getElementById("erro-dk");

        erroDk.classList.add("active");
        erroDk.innerText = resposta;

        erroMb.classList.add("active");
        erroMb.innerText = resposta;

      }
    }
  }

    let formData = new FormData(mensagem)
  xml.send(formData);
}
	</script>

    
    
    <!-- footer -->
    <?php include_once("hf/footer.php")?>
