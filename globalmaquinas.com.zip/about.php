<?php include_once("hf/header.php")?>

  <!-- fim header -->

  <main>
    <article class="about" class="section-p1">
      
        <img src="img/globalmaquinas.jpeg" width="100%" alt="">
      
      

        <div class="text-about">
          <h2>Quem Somos!</h2>
          <p>A GlobalMáquinas - Equipamentos Industriais, Lda, é uma empresa de direito angolano, vocacionada para a comercialização de máquinas e equipamentos para a indústria e comércio, nomeadamente grupos electrogéneos (geradores), de 6 a 3000 kwa, a GlobalMáquinas assume também a manutenção e assistência dos seus equipamentos, mas também aos que não são comercializados pela empresa.</p>
          <p>Possuímos equipas especializadas de manutenções, em todo o território nacional, nomeadamente no que diz respeito aos geradores da marca Pramac (prestigiada marca europeia).</p>
          <p>Consideramos que os nossos conhecimentos técnicos e equipamentos disponíveis poderão ser uma mais valia para qualquer instituição, na medida em que garantimos qualidade a preços competitivos de mercado</p>
          <marquee loop="-1" scrollamount="5" with="100%">Rua do Dream space, Estrada do Kikuxi, Viana, Luanda</marquee>
        </div>
        
      
    </article>
    <section class="section-p1" id="feature">
    <figure class="fe-box">
      <img src="img/f1.png" alt="">
      <h6>Transporte Grátis</h6>
    </figure>
    <figure class="fe-box">
      <img src="img/f2.png" alt="">
      <h6>Pedido On-line</h6>
    </figure>
    <figure class="fe-box">
      <img src="img/f3.png" alt="">
      <h6>Pagamento Seguro</h6>
    </figure>
    <figure class="fe-box">
      <img src="img/f4.png" alt="">
      <h6>Promoção</h6>
    </figure>
    <figure class="fe-box">
      <img src="img/f5.png" alt="">
      <h6>Promove Felicidade</h6>
    </figure>
    <figure class="fe-box">
      <img src="img/f6.png" alt="">
      <h6>F24/7 Suporte</h6>
    </figure>
  </section>
    
    
    <!-- footer -->
<?php include_once("hf/footer.php")?>
    