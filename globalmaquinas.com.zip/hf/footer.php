 
 <section id="newsletter" class="section-p1 section-m1">
   <div class="newstext">
     <h4>Entrar</h4>
     <p>Inicie sessão para futuras actualizações e <span>Ofertas Especiais</span></p>
   </div>

   <form class="login-email">
     <input type="email" name="email" id="email" value="<?= isset($_SESSION["email"])? $_SESSION["email"]: "" ?>" placeholder="Teu Endereço de E-mail" required <?= isset($_SESSION["nivelAcesso"])? "disabled": "" ?> > 
     <button type="submit" class="normal" <?= isset($_SESSION["nivelAcesso"])? "disabled": "" ?> >Entrar</button>
   </form>
   <script>
	  const signup = document.querySelector(".login-email"),
	  entrar = signup.querySelector(".login-email button");

	signup.onsubmit = (e) => {
	  e.preventDefault();
	}

	entrar.onclick = () => {
	  let xml = new XMLHttpRequest();
	  xml.open("POST", "php/logar2.php", true);

	  xml.onreadystatechange = () => {
		if(xml.readyState === XMLHttpRequest.DONE && xml.status === 200){
		  let resposta = xml.response;
		  if(resposta == "Sucesso") {
			  window.location.reload();
			
		  }else {
			  document.querySelector(".login-email input").classList.add("active");

		  }
		}
	  }
		let formData = new FormData(signup);
		xml.send(formData);
	}
   </script>
	

	
 </section>
 <footer id="footer" class="section-p1">
   <div class="col">
     <img src="img/logonobg.png" alt="" class="logo">
     <h4>Contactos</h4>
     <p>
       <address><strong>Endereço: </strong>Rua do Dream space, Estr. do Kikuxi, Viana</address>
     </p>
     <p><strong>Telefone:</strong> (+244) 948 451 449 / (+244) 945 627 088</p>
     <p><time><strong>Horários:</strong>08:00 - 17:30, Mon - Fri</time></p>
     <p><time><strong>Horários:</strong>08:00 - 12:00, Sat</time></p>

     <div class="follow">
       <h4>Siga-Nos</h4>
       <div class="icons">
         <a href="#" class="fab fa-facebook-f"></a>
         <a href="#" class="fab fa-twitter"></a>
         <a href="#" class="fab fa-instagram"></a>
         <a href="#" class="fab fa-pinterest-p"></a>
         <a href="#" class="fab fa-youtube"></a>

       </div>
     </div>
   </div>

   <div class="col">
     <h4>Sobre</h4>
     <a href="about.php"> Sobre-Nós</a>
     <a href="#">Delivery information</a>
     <a href="#">Politica & privacidade</a>
     <a href="#">Termos & Condições</a>
     <a href="contact.php">Contacto</a>
   </div>

   <div class="col">
     <h4>Minha Conta</h4>
	
	<?php if(!isset($_SESSION["email"])){?>
     <a href="login.php">Entrar</a>
	<?php }else {  ?>
	<a href="logout.php"><?= $_SESSION["nome"]; ?> (Sair)</a>
	<?php    }?>
	
     <a href="cart.php">ver carrinho</a>
     <a href="#">Meus desejos</a>
     <a href="minhasRotas.php">Minhas Rotas</a>
     <a href="#"> Ajuda</a>
   </div>

   <div class="col install">
     <h4>Aplicações</h4>
     <p>Da App Store ou Google Play</p>
     <div class="row">
       <img src="img/Google-Play.png" alt="">
       <img src="img/App-Store.png" alt="">
     </div>
     <p>Metodos de pagamentos</p>
     <div class="paycard-col">
            <img src="img/logo-bai.svg" width="90px" height="37px">
            <img src="img/atlantico.png" width="90px" height="37px">
            <img src="img/sol.png" width="90px" height="50px">
          </div>
   </div>

   <div class="copyright">
     <p>PAP: &copy; 2021, Manuel Guengui.
<span>- HTML CSS, JS, PHP</span></p>
   </div>
 </footer>
 </main>
 
 <script>
  //add producto para o carrinho
	function addCart(producto, user){
		
	let xml = new XMLHttpRequest();
	xml.open("get", `php/crudClient.php?producto=${producto}&user=${user}`, true);
	xml.onreadystatechange=()=> {
		if(xml.status == 200 && xml.readyState === XMLHttpRequest.DONE){
			 let resposta = xml.response;
			
		 }
	}
	xml.send();
}


//Quantidade de producto no carrinho
 setInterval(()=>{
	 let xml = new XMLHttpRequest();
		xml.open("get", "php/crudClient.php?qtd=n", true);
		xml.onreadystatechange=()=> {
		if(xml.status == 200 && xml.readyState === XMLHttpRequest.DONE){
			let resposta = xml.response;
			document.querySelector(".icon-user-nav .shop i").textContent = resposta;
		}
	}
	xml.send();
 },30)

 </script>
 <script src="js/script.js"></script>
 </body>

 </html>