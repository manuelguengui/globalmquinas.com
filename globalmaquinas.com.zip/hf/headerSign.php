<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
  <link rel="stylesheet" href="css/mobile.css">
  <link rel="stylesheet" href="css/tablet.css">
  <link rel="stylesheet" href="css/desktop.css">
  

  <title>Global Maquinas | sign</title>
</head>

<body>
  <header>

    <div class="alert-dk">
      <p id="erro-dk"></p>
    </div>

    <div class="conteiner">
      <section class="conteiner-bar">
        <h1><a href="index.php"><img src="img/logonobg.png" alt=""></a></h1>
      </section>
    </div>

  </header>