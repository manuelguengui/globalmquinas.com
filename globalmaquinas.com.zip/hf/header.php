<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" />
  <link rel="stylesheet" href="css/mobile.css">
  <link rel="stylesheet" href="css/tablet.css">
  <link rel="stylesheet" href="css/desktop.css">

  <title>Global Máquinas -- Máquinas e equipamentos</title>
</head>

<body>
  <header>
    <div class="alert-dk">
      <p id="erro-dk"></p>
    </div>
    <div class="conteiner">

      <section class="conteiner-bar">
        <h1><a href="index.php"><img src="img/logonobg.png" alt=""></a></h1>

        <i class="fas fa-bars bar"></i>
        <i class="fas fa-times times"></i>
      </section>

      <div>

        <ul class="icon-user-nav">
          <li><a href="cart.php" class="fal fa-shopping-cart shop"><i></i></a></li>
          <?php if(!isset($_SESSION["email"])){?>
          <li><a href="login.php" class="far fa-user"></a></li>
          <?php }else {  ?>
            <li><a href="logout.php" class="fad fa-sign-out"></a></li>
            <?php    }?>
        </ul>



        
     


        <section class="row">

          <div class="col">

            <nav class="nav-conteiner">
              <ul class="menu nav">
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Producto</a></li>
                <li><a href="contact.php">Contacto</a></li>
                <li><a href="about.php">Sobre</a></li>
              </ul>
            </nav>


            <?php  if((isset($_SESSION["nivelAcesso"]) && $_SESSION["nivelAcesso"] == "Admin")){ ?>

              <nav class="admin-conteiner">
                <ul class="nav">
                  <li><a href="admin.php">Admin</a></li>
                </ul>
              </nav>
			  
			<?php    }?>

           

          </div>

        </section>
      </div>

    </div>
  </header>