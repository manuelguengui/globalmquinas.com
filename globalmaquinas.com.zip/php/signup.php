<?php
session_start();
require("class/cadastrar.php");
require("class/conexao.php");

$con = new CONEXAO();
$cadastrar = new CADASTRAR($con);
	
if($_POST){
$cadastrar->__set("nome", ucfirst($_POST["pnome"]));
$cadastrar->__set("snome", ucfirst($_POST["snome"]));
$cadastrar->__set("email", strtolower($_POST["email"]));
$cadastrar->__set("senha", $_POST["senha"]);
$cadastrar->__set("nivelAcesso", ucfirst("Cliente"));

if($cadastrar->cadastrar() == true){
	$_SESSION["id"] = $cadastrar->__get("id");
	$_SESSION["nivelAcesso"] = $cadastrar->__get("nivelAcesso");
	$_SESSION["email"] = $cadastrar->__get("email");
	$_SESSION["nome"] = $cadastrar->__get("nome");
	$_SESSION["snome"] = $cadastrar->__get("snome");
	echo "sucesso";
}
}else {
	header("location:../signup.php");
}

	

		


