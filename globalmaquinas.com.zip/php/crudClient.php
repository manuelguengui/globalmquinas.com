<?php
session_start();
require("class/conexao.php");
require("class/cliente.php");

$conexao = new conexao();
$crud = new CLIENTE($conexao);

if($_POST){
	//Finalizar compra
	if(!empty($_POST["pagamento"])){
		$crud->__set("idUser", (int)$_SESSION["id"]);
		$crud->__set("nome", $_POST["nome"]);
		$crud->__set("email", $_POST["email"]);
		$crud->__set("endereco", $_POST["endereco"]);
		$crud->__set("bancoPagamento", $_POST["pagamento"]);

		if($crud->comprar() == true){
			echo "Sucesso";
		}else {
			echo "O seu carrinho esta Vázio";
		}
		
	}else {
		echo "Marca o pagamento na Entrega";
	}

}



if($_GET){
	
	if(isset($_GET["producto"]) && isset($_GET["user"])){
	$crud->__set("idProducto", (int)$_GET["producto"]);
	$crud->__set("idUser", $_GET["user"]);
		
	$crud->addCarrinho();
	}
	
	if(isset($_GET["id"]) && isset($_GET["user"])){
	$crud->__set("id", $_GET["id"]);
	$crud->__set("idUser", $_GET["user"]);
	$crud->__set("quantidade", $_GET["valor"]);
	$crud->actualizar();
		
	}
	
	if(isset($_GET["remover"]) && isset($_GET["user"])){
	$crud->__set("id", $_GET["remover"]);
	$crud->__set("idUser", $_GET["user"]);
	$crud->remover();
		
		
	}
	
	
	
}
if(isset($_GET["qtd"]) && $_GET["qtd"] == "n"){
	if(isset($_SESSION["id"]) && ($_SESSION["nivelAcesso"] != "Admin")){
		$crud->__set("idUser", $_SESSION["id"]);
		$crud->cartNum();
	}
}
//Exibir o total de producto a pagar
if(isset($_GET["custo"]) && $_GET["custo"] == "custo"){
	if(isset($_SESSION["id"]) && ($_SESSION["nivelAcesso"] != "Admin")){
		$crud->__set("idUser", $_SESSION["id"]);
		$crud->custo();
		echo number_format($crud->__get("preco"), 2, ",", ".") ."Kz";
		
	}
}	


?>