<?php
session_start();
require("class/conexao.php");
require("class/entrar.php");

$conexao = new CONEXAO();
$entrar = new ENTRAR($conexao);
if($_POST){
	$entrar->__set("email", $_POST["email"]);
	
	if($entrar->entrarEmail() == "Sucesso"){
		$_SESSION["id"] = $entrar->__get("id");
		$_SESSION["nivelAcesso"] = $entrar->__get("nivelAcesso");
		$_SESSION["email"] = $entrar->__get("email");
		$_SESSION["nome"] = $entrar->__get("nome");
		$_SESSION["snome"] = $entrar->__get("snome");
		echo "Sucesso";	
		
	}
	
}else {
	header("location:../index.php");
}


?> 
 