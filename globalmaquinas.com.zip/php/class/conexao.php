<?php
class CONEXAO {
  private $dsn = "mysql:host=localhost;dbname=globalmaquinas";
  private $root = "root";
  private $password = "";

  public function conectar(){
    try{
      $conexao = new PDO($this->dsn, $this->root, $this->password);
      return $conexao;
      

    }catch(PDOException $e){
      echo "erro na conexao";
    }
  }

}












