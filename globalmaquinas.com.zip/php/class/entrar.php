<?php
class ENTRAR  {
  private $id;
  private $conexao;
  private $email;
  private $nome;
  private $snome;
  private $senha;
  private $nivelAcesso;
  public function __construct(CONEXAO $conexao){
	$this->conexao = $conexao->conectar();
  }


  public function entrar(){
    if(empty($this->email) || empty($this->senha)){
		
		echo "É necessáro que preenchas todos os compos";
	}else{
		if(filter_var($this->email, FILTER_VALIDATE_EMAIL)){
			$sql = "SELECT * FROM user WHERE email = :email AND password = :senha";
			$stmt = $this->conexao->prepare($sql);
			$stmt->bindValue(":email",strtolower( $this->email));
			$stmt->bindValue(":senha", md5($this->senha));
			$stmt->execute();
			
			if($stmt->rowCount() > 0){
				$row = $stmt->fetch();
				$this->nivelAcesso = $row["nivel_acesso"];
				$this->id = $row["id"];
				$this->email = $row["email"];
				$this->nome = ucfirst($row["p_nome"]);
				$this->snome = ucfirst($row["s_nome"]);
				
				return true;
				
			}else {
				echo "Email ou Senha Incorrecto";
				return false;
			}
		}else{
			echo "Este E-mail não é válido";
		}
	}
  }

  public function entrarEmail(){
	if(empty($this->email)){
		echo "Digite o E-mail";
	}else {
		if(!filter_var($this->email, FILTER_VALIDATE_EMAIL)){
			echo"Digite um Endereço de E-mail Válido";
		}else{
			$sql = "SELECT * FROM user WHERE email = :email";
			$stmt = $this->conexao->prepare($sql);
			$stmt->bindValue(":email", $this->email);
			$stmt->execute();
			
			if($stmt->rowCount() > 0){
				$row = $stmt->fetch();
				
				if($row["nivel_acesso"] == "Admin"){
					echo "Apenas Clientes devem acessar apartir deste Campo";
					return false;
				}else {
					$this->id = $row["id"];
					$this->nivelAcesso = $row["nivel_acesso"];
					$this->email = $row["email"];
					$this->nome = ucfirst($row["p_nome"]);
					$this->snome = ucfirst($row["s_nome"]);
					
					return "Sucesso";
				}
			}else {
				echo "Não existe um usuário com este E-mail";
			}
		}
	}
  }
  function __set($atributo, $valor){
    $this->$atributo = $valor;
  }

  function __get($atributo){
    return $this->$atributo;
  }
}


?>