<?php

class CADASTRAR {
  private $id;
  private $conexao;
  private $nome;
  private $snome;
  private $email;
  private $senha;
  private $nivelAcesso;


  public function __construct(CONEXAO $conexao){
    $this->conexao = $conexao->conectar();
  }

  public function cadastrar(){
    if(empty($this->nome) || empty($this->snome) || empty($this->nivelAcesso) || empty($this->senha) || empty($this->email)){
	echo "É necessário que todos os campos sejam preenchidos";
	}else {
		if(filter_var($this->email, FILTER_VALIDATE_EMAIL)){
			
			$sql = "SELECT * FROM user WHERE email = :email";
			$stmt = $this->conexao->prepare($sql);
			$stmt->bindValue(":email", $this->email);
			$stmt->execute();
			
			if($stmt->rowCount() > 0){
				echo "O Já existe um usuário  com este email";
			}else {
				$sql = "INSERT INTO user(p_nome, s_nome, email, password, nivel_acesso) VALUES (:nome, :snome, :email, 
				:senha, :nivelAcesso)";
				$stmt = $this->conexao->prepare($sql);
				$stmt->bindValue(":nome", ucfirst($this->nome));
				$stmt->bindValue(":snome", ucfirst($this->snome));
				$stmt->bindValue(":email", strtolower($this->email));
				$stmt->bindValue(":senha", md5($this->senha));
				$stmt->bindValue(":nivelAcesso", ucfirst($this->nivelAcesso));
				$stmt->execute();
				
				if($stmt->rowCount() > 0){
					
					$sql = "SELECT * FROM user WHERE email = :email AND password = :senha";
					$stmt = $this->conexao->prepare($sql);
					$stmt->bindValue(":email", $this->email);
					$stmt->bindValue(":senha", md5($this->senha));
					$stmt->execute();
					
					$row = $stmt->fetch();
					
					$this->id = $row["id"];
					$this->nivelAcesso = $row["nivel_acesso"];
					$this->email = $row["email"];
					$this->nome = ucfirst($row["p_nome"]);
					$this->snome = ucfirst($row["s_nome"]);
					
					return true;
				}else{
					return false;
				}
			}
			
		}else {
			echo "Este email não é válido";
		}
	}
  }
  
  function __set($atributo, $valor){
    $this->$atributo = $valor;
  }

  function __get($atributo){
    return $this->$atributo;
  }
}


?>