<?php

class CLIENTE{
  private $id;
  private $idUser;
  private $idProducto;
  private $producto;
  private $quantidade = 1;
  private $marca;
  private $preco;
  private $descricao;
  private $conexao;
  private $custo;
  private $nome;
  private $email;
  private $endereco;
  private $bancoPagamento;
  
  public function  __construct(CONEXAO $conexao){
		$this->conexao = $conexao->conectar();
		}
		function addCarrinho(){
		if(empty($this->idProducto) || empty($this->idUser)){
		echo "É necessário que o Cliente Inicia sessão";
		}else {
		$sql = "SELECT * FROM producto WHERE id = :idProducto";
		$stmt = $this->conexao->prepare($sql);
		$stmt->bindValue(":idProducto", $this->idProducto);
		$stmt->execute();
		
		if($stmt->rowCount() > 0){
			$row = $stmt->fetch();
			$productoId = (int)$row["id"];
			$productoP = $row["producto"];
			$productoMarca = $row["marca"];
			$productoPreco = (int)$row["preco"];
			$productoDscr = $row["descricao"];
			
			$sql = "SELECT * FROM carrinho WHERE id_user = :idUser AND id_producto = :idProducto";
			$stmt = $this->conexao->prepare($sql);
			$stmt->bindValue(":idUser", $this->idUser);
			$stmt->bindValue(":idProducto", $this->idProducto);
			$stmt->execute();
			
			
			if($stmt->rowCount() > 0){
				echo "Já tens Este producto no seu carrinho";
			}else {
				$sql = "INSERT INTO carrinho(id_user, id_producto, producto, marca, preco, quantidade, descricao)
				VALUES(:idUser, :idProducto, :productoP, :productoMarca, :productoPreco, :quantidade, :productoDscr)";
				$stmt = $this->conexao->prepare($sql);
				$stmt->bindValue(":idUser", $this->idUser);
				$stmt->bindValue(":idProducto", $this->idProducto);
				$stmt->bindValue(":productoP", $productoP);
				$stmt->bindValue(":productoMarca", $productoMarca);
				$stmt->bindValue(":productoPreco", $productoPreco);
				$stmt->bindValue(":quantidade", $this->quantidade);
				$stmt->bindValue(":productoDscr", $productoDscr);
				$stmt->execute();
				echo "chegamos até aqui";
			
			}
		}
	}
  }
  function actualizar(){
	if(!empty($this->idUser)){
		$sql = "UPDATE Carrinho SET quantidade = :quantidade WHERE id = :id AND id_user = :idUser";
		$stmt = $this->conexao->prepare($sql);
		$stmt->bindValue(":quantidade", $this->quantidade);
		$stmt->bindValue(":id", $this->id);
		$stmt->bindValue(":idUser", $this->idUser);
		$stmt->execute();
		
	}else {
		echo "Inicia Sessão rara realizar compra";
	}
	
  }
  
  function remover(){
	$sql = "DELETE FROM carrinho WHERE id = :id AND id_user = :idUser";
	$stmt = $this->conexao->prepare($sql);
	$stmt->bindValue(":id", $this->id);
	$stmt->bindValue(":idUser", $this->idUser);
	$stmt->execute();
	echo "sucesso";
  }
  
  function comprar(){
	if(empty($this->email) || empty($this->nome) || empty($this->idUser) || empty($this->endereco) || empty($this->bancoPagamento)) {
		echo "É necessário que preenchas todos os campos \n";
	}else {
		$sql="SELECT *  FROM carrinho WHERE id_user = :idUser";
		$stmt = $this->conexao->prepare($sql);
		$stmt->bindValue(":idUser", $this->idUser);
		$stmt->execute();

		foreach($stmt->fetchAll() as $row){
			$this->producto.= "(". $row["quantidade"].")". $row["producto"] .": ". $row["descricao"] .". ";
		}
		$productos = $this->producto;

		if($stmt->rowCount() > 0){
			$sql ="SELECT SUM(preco * quantidade) AS total FROM carrinho WHERE id_user = :idUser";
			$stmt= $this->conexao->prepare($sql);
			$stmt->bindValue("idUser", $this->idUser);
			$stmt->execute();
			$row = $stmt->fetch();

			$sql = "INSERT INTO compra(id_user, nome_cliente, email_cliente, endereco, producto, pagamento, banco_pagamento, entrega) VALUES (:idUser, :nome, :email, :endereco, :productos, :pagamento, :bancoPagamento, :entrega)";
			$stmt=$this->conexao->prepare($sql);
			$stmt->bindValue(":idUser",$this->idUser);
			$stmt->bindValue(":nome",$this->nome);
			$stmt->bindValue(":email",$this->email);
			$stmt->bindValue(":endereco",$this->endereco);
			$stmt->bindValue(":productos", $productos);
			$stmt->bindValue(":pagamento", $row["total"]);
			$stmt->bindValue(":bancoPagamento",$this->bancoPagamento);
			$stmt->bindValue(":entrega","Não realizada");
			$stmt->execute();
			return true;
			
		}

	}
  }
  
  function cartNum(){
	 $sql = "SELECT * FROM carrinho WHERE id_user = :idUser";
	 $stmt = $this->conexao->prepare($sql);
	 $stmt->bindValue(":idUser", $this->idUser);
	 $stmt->execute(); 
	 echo $stmt->rowCount();
	 
  }
   function custo(){
	  if(!empty($this->idUser)){
		 $sql ="SELECT SUM(preco * quantidade) AS total FROM carrinho WHERE id_user = :idUser";
		 $stmt= $this->conexao->prepare($sql);
		 $stmt->bindValue("idUser", $this->idUser);
		$stmt->execute();
		$row = $stmt->fetch();

		$this->preco = $row["total"];

		
		 
	  }
   }

  function __set($atributo, $valor){
	 $this->$atributo = $valor;
  }

  function __get($atributo){
    return $this->$atributo;
  }
  
}
?>