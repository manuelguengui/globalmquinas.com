<?php
class ADMIN{
  private $id;
  public $producto;
  public $marca;
  public $preco;
  public $descricao;
  public $quantidade;
  private $imagem;
  private $conexao;
  
  public function __construct(CONEXAO $conexao){
	$this->conexao = $conexao->conectar();
	
  }

  function inserir(){
    if(empty($this->producto) || empty($this->marca) || empty($this->preco) || empty($this->descricao) || empty($this->quantidade)){
		echo "Preencha todos os Campo";
	}else {
		if(empty($this->imagem)){
			echo "Coloca uma Imagem do producto";
		}else {
			$sql = "INSERT INTO producto(producto, marca, preco, descricao, img, quantidade) VALUES (:producto, :marca,
			:preco, :descricao, :imagem, :quantidade)";
			$stmt = $this->conexao->prepare($sql);
			$stmt->BindValue(":producto", ucfirst($this->producto));
			$stmt->BindValue(":marca", ucfirst($this->marca));
			$stmt->BindValue(":preco", (int)$this->preco);
			$stmt->BindValue(":descricao", $this->descricao);
			$stmt->BindValue(":imagem", $this->imagem);
			$stmt->BindValue(":quantidade", (int)$this->quantidade);
			$stmt->execute();
			return true;
		  }
		}
	}
	

  function apagar(){
	if(!empty($this->id)){
		$sql = "DELETE FROM producto WHERE id = :id";
		$stmt= $this->conexao->prepare($sql);
		$stmt->bindValue(":id", $this->id);
		$stmt->execute();
		
		if($stmt->rowCount() > 0){
			return true;
		}else {
			return false;
		}
	}
  }
  
  function realizar(){
	if(!empty($this->id)){
		$sql = $sql = "UPDATE compra SET entrega = :realizada WHERE id = :id";
		$stmt= $this->conexao->prepare($sql);
		$stmt->bindValue(":id", $this->id);
		$stmt->bindValue(":realizada", "Realizada");
		$stmt->execute();
		
		if($stmt->rowCount() > 0){
			return true;
		}else {
			return false;
		}
	}
  }

  function actualizar(){
	if(empty($this->id) || empty($this->producto) || empty($this->marca) || empty($this->preco) || empty($this->descricao) || empty($this->quantidade)){
		echo "Preencha dotos os compos do productos. \n";
	}else {
		$sql = "UPDATE producto SET producto = :producto, marca = :marca, preco = :preco, descricao = :dscr, quantidade = :qtd WHERE id = :id";
		$stmt = $this->conexao->prepare($sql);
		$stmt->bindValue(":producto", $this->producto);
		$stmt->bindValue(":marca", $this->marca);
		$stmt->bindValue(":preco", $this->preco);
		$stmt->bindValue(":dscr", $this->descricao);
		$stmt->bindValue(":qtd", $this->quantidade);
		$stmt->bindValue(":id", $this->id);
		$stmt->execute();

		if($stmt->rowCount() > 0){
			return "Sucesso";
		}else {
			return false;
		}

	}
  }

  
  function __set($atributo, $valor){
    $this->$atributo = $valor;
  }

  function __get($atributo){
    return $this->$atributo;
  }
  
}


?>
