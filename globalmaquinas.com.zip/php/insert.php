<?php
require("class/conexao.php");
require("class/admin.php");

$conexao = new CONEXAO();
$insert = new ADMIN($conexao);

if($_POST){
	$insert->__set("producto", ucfirst($_POST["producto"]));
	$insert->__set("marca", ucfirst($_POST["marca"]));
	$insert->__set("preco", (int)$_POST["preco"]);
	$insert->__set("descricao", $_POST["dscr"]);
	$insert->__set("quantidade", (int)$_POST["qtd"]);
	
	if(isset($_FILES["img"])){
		
		$img = $_FILES["img"]["name"];
		$tmp = $_FILES["img"]["tmp_name"];
		$size = $_FILES["img"]["size"];
		
		
		$imgExplode = explode(".", $img);
		$extensao = end($imgExplode);
		$extensaoValida = ["png", "jpg", "jpeg", "PNG", "JPG", "JPEG"];		
		
		if(in_array($extensao, $extensaoValida)){
			
			if($size >= 1677721){
				echo "Esta imagem é muito Grande";
			}else{
				$time = time();
				$imagem = $time.$img;
				$insert->__set("imagem", $imagem);
				
				if($insert->inserir() == true) {
					move_uploaded_file($tmp,"../productos/".$imagem);
					echo "Sucesso";
				}else{
					echo "Alguma coisa Ocorreu mal, tente novamente"; 
				}
			}
			
		}else{
			echo "Coloca uma imagem do tipo png, jpg, jpeg";
		}
		
	}else {
		echo "Coloca uma Imagem do producto";
	}
}else{
	header("../admin.php");
}


?>