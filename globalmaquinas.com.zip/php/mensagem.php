<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
 
//Load Composer's autoloader
require 'vendor/autoload.php';
if($_POST){
	if(empty($_POST["emailFrom"]) || empty($_POST["assunto"]) || empty($_POST["sms"]) || empty($_POST["nome"]) || empty($_POST["snome"])){
		echo "É necessário preencher todos os campos";
	}else{
		if(!filter_var($_POST["emailFrom"], FILTER_VALIDATE_EMAIL)){
			echo "Digitaste um E-mail invalido";
		}else{
			//Create an instance; passing `true` enables exceptions
			$mail = new PHPMailer(true);

			try {
				//Server settings
				//$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
				$mail->isSMTP();                                            //Send using SMTP
				$mail->Host       = 'smtp.gmail.com.';                     //Set the SMTP server to send through
				$mail->SMTPAuth   = true;                                   //Enable SMTP authentication
				$mail->Username   = 'globalmaquinas6@gmail.com';                     //SMTP username
				$mail->Password   = 'ysbaoldmpqxrsglo';                               //SMTP password
				$mail->SMTPSecure = "PHPMailer::ENCRYPTION_STARTTLS";            //Enable implicit TLS encryption
				$mail->Port       = 587;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

				//Recipients
				$mail->setFrom($_POST["emailFrom"], $_POST["emailFrom"]);
				$mail->addAddress('globalmaquinas6@gmail.com', 'Gblobal Maquinás');     //Add a recipient
				
				//Content
				$mail->isHTML(true);                                  //Set email format to HTML
				$mail->Subject = $_POST["assunto"];
				$mail->Body    = $_POST["sms"];
				$mail->send();
				
				echo 'Sucesso';
				
			} catch (Exception $e) {
				echo "Ocorreu um erro! verifica a tua internet ou tente mais tarde";
			}
		}
	}
}else{
	header("localtion:../contact.php");
}