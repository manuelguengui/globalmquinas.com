<?php
session_start();
require("class/conexao.php");
$conexao = new CONEXAO();
$conexao = $conexao->conectar();
$dados ="";




//pesquisar productos;
if($_POST){
	
	$sql = "SELECT * FROM producto WHERE producto LIKE '%{$_POST["search"]}%' OR descricao LIKE '%{$_POST["search"]}%'";
	$stmt = $conexao->prepare($sql);
	$stmt->execute();

	foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
		$dados .='
			<figure class="pro">
				<img src="productos/'.$row["img"].'">
				<div class="des">
				<div class="see">
				<h5>'.$row["producto"].'</h5>

				<a href="f-product.php?produto='.$row["id"].'" class="fas fa-eye"></a> </div>
				<div class="star">
					<i class="fas fa-star"></i>
					<i class="fas fa-star"></i>
					<i class="fas fa-star"></i>
					<i class="fas fa-star"></i>
					<i class="fas fa-star"></i>
				</div>
				<h4>'.number_format($row["preco"], 2, ",", ".").'Kz</h4>
				</div>
			 <a onclick="addCart('.$row["id"].','.$_SESSION["id"] .')" class="btn-cart"><i class="fal fa-shopping-cart cart"></i></a>
			</figure>';
	}
	echo $dados;
}




if($_GET){
	
	//producto da pagina de index
	if(isset($_GET["producto"]) && $_GET["producto"] == "index"){
		if(isset($_SESSION["id"]) && $_SESSION["nivelAcesso"] != "Admin"){
			$sql = "SELECT * FROM producto ORDER BY id DESC LIMIT 4";
			$stmt = $conexao->prepare($sql);
			$stmt->execute();

			foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
				$dados .='
					<figure class="pro">
					  <img src="productos/'.$row["img"].'">
					  <div class="des">
						<div class="see">
						<h5>'.$row["producto"].'</h5>

						<a href="f-product.php?produto='.$row["id"].'" class="fas fa-eye"></a> </div>
						<div class="star">
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						</div>
						<h4>'.number_format($row["preco"], 2, ",", ".").'Kz</h4>
					  </div>
					 <a onclick="addCart('.$row["id"].','.$_SESSION["id"] .')" class="btn-cart"><i class="fal fa-shopping-cart cart"></i></a>
					</figure>';
			}
			echo $dados;
		}else {
			$sql = "SELECT * FROM producto ORDER BY id DESC LIMIT 4";
		$stmt = $conexao->prepare($sql);
			$stmt->execute();

			foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
				$dados .='
					<figure class="pro">
					  <img src="productos/'.$row["img"].'">
					  <div class="des">
						<div class="see">
						<h5>'.$row["producto"].'</h5>

						<a href="f-product.php?produto='.$row["id"].'" class="fas fa-eye"></a> </div>
						<div class="star">
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						</div>
						<h4>'.number_format($row["preco"], 2, ",", ".").'kz</h4>
					  </div>
					 <a onclick="addCart('.$row["id"].')" class="btn-cart"><i class="fal fa-shopping-cart cart"></i></a>
					</figure>';
			}
			echo $dados;
			
		}
	}
	
	
	
	//Código para a tela de productos
	if(isset($_GET["producto"]) && $_GET["producto"] == "producto"){
		
			$pagina = isset($_GET["paginar"])? $_GET["paginar"]: 1;
			$pagina = (int)$pagina;
			$quantiadade  = 8;
			$inicio = ($pagina * $quantiadade) - $quantiadade;
			
			if(isset($_SESSION["id"]) && $_SESSION["nivelAcesso"] != "Admin"){
			$sql = "SELECT * FROM producto ORDER BY id DESC LIMIT $inicio, $quantiadade";
			$stmt = $conexao->prepare($sql);
			$stmt->execute();

			foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
				$dados .='
					<figure class="pro">
					  <img src="productos/'.$row["img"].'">
					  <div class="des">
						<div class="see">
						<h5>'.$row["producto"].'</h5>

						<a href="f-product.php?produto='.$row["id"].'" class="fas fa-eye"></a> </div>
						<div class="star">
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						</div>
						<h4>'.number_format($row["preco"], 2, ",", ".").'Kz</h4>
					  </div>
					 <a onclick="addCart('.$row["id"].','.$_SESSION["id"] .')" class="btn-cart"><i class="fal fa-shopping-cart cart"></i></a>
					</figure>';
			}
			echo $dados;
		
		
		}else {
		
			
			$pagina = isset($_GET["paginar"])? $_GET["paginar"]: 1;
			$pagina = (int)$pagina;
			$quantiadade  = 8;
			$inicio = ($pagina * $quantiadade) - $quantiadade;
			
			$sql = "SELECT * FROM producto ORDER BY id DESC LIMIT $inicio, $quantiadade";
		
			$stmt = $conexao->prepare($sql);
			$stmt->execute();

			foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
				$dados .='
					<figure class="pro">
					  <img src="productos/'.$row["img"].'">
					  <div class="des">
						<div class="see">
						<h5>'.$row["producto"].'</h5>

						<a href="f-product.php?produto='.$row["id"].'" class="fas fa-eye"></a> </div>
						<div class="star">
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						</div>
						<h4>'.number_format($row["preco"], 2, ",", ".").'Kz</h4>
					  </div>
					 <a onclick="addCart('.$row["id"].')" class="btn-cart"><i class="fal fa-shopping-cart cart"></i></a>
					</figure>';
			}
			echo $dados;
			
		
		}
	}
	
	
	
	//producto da particolar em destaqui
	
	if(isset($_GET["producto"]) && $_GET["producto"] == "f-producto"){
		if(isset($_SESSION["id"]) && $_SESSION["nivelAcesso"] != "Admin"){
			$sql = "SELECT * FROM producto ORDER BY id DESC LIMIT 4";
		$stmt = $conexao->prepare($sql);
			$stmt->execute();

			foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
				$dados .='
					<figure class="pro">
					  <img src="productos/'.$row["img"].'">
					  <div class="des">
						<div class="see">
						<h5>'.$row["producto"].'</h5>

						<a href="f-product.php?produto='.$row["id"].'" class="fas fa-eye"></a> </div>
						<div class="star">
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						</div>
						<h4>'.number_format($row["preco"], 2, ",", ".").'Kz</h4>
					  </div>
					 <a onclick="addCart('.$row["id"].','.$_SESSION["id"] .')" class="btn-cart"><i class="fal fa-shopping-cart cart"></i></a>
					</figure>';
			}
			echo $dados;
		}else {
			$sql = "SELECT * FROM producto ORDER BY id DESC LIMIT 4";
		$stmt = $conexao->prepare($sql);
			$stmt->execute();

			foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
				$dados .='
					<figure class="pro">
					  <img src="productos/'.$row["img"].'">
					  <div class="des">
						<div class="see">
						<h5>'.$row["producto"].'</h5>

						<a href="f-product.php?produto='.$row["id"].'" class="fas fa-eye"></a> </div>
						<div class="star">
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						</div>
						<h4>'.number_format($row["preco"], 2, ",", ".").'Kz</h4>
					  </div>
					 <a onclick="addCart('.$row["id"].')" class="btn-cart"><i class="fal fa-shopping-cart cart"></i></a>
					</figure>';
			}
			echo $dados;
			
		}
	}
	
	//paginação
	if(isset($_GET["paginar"])){
	$pagina = (int)$_GET["paginar"];
	$quantiadade  = 8;
	$inicio = ($pagina * $quantiadade) - $quantiadade;
			
		if(isset($_SESSION["id"]) && $_SESSION["nivelAcesso"] != "Admin"){
			$sql = "SELECT * FROM producto ORDER BY id DESC LIMIT $inicio, $quantiadade";
		
			$stmt = $conexao->prepare($sql);
			$stmt->execute();

			foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
				$dados .='
					<figure class="pro">
					  <img src="productos/'.$row["img"].'">
					  <div class="des">
						<div class="see">
						<h5>'.$row["producto"].'</h5>

						<a href="f-product.php?produto='.$row["id"].'" class="fas fa-eye"></a> </div>
						<div class="star">
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						</div>
						<h4>'.number_format($row["preco"], 2, ",", ".").'Kz</h4>
					  </div>
					 <a onclick="addCart('.$row["id"].','.$_SESSION["id"] .')" class="btn-cart"><i class="fal fa-shopping-cart cart"></i></a>
					</figure>';
			}
			echo $dados;
		}else {
			$sql = "SELECT * FROM producto ORDER BY id DESC LIMIT $inicio, $quantiadade";
		
			$stmt = $conexao->prepare($sql);
			$stmt->execute();

			foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
				$dados .='
					<figure class="pro">
					  <img src="productos/'.$row["img"].'">
					  <div class="des">
						<div class="see">
						<h5>'.$row["producto"].'</h5>

						<a href="f-product.php?produto='.$row["id"].'" class="fas fa-eye"></a> </div>
						<div class="star">
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						  <i class="fas fa-star"></i>
						</div>
						<h4>'.number_format($row["preco"], 2, ",", ".").'Kz</h4>
					  </div>
					 <a onclick="addCart('.$row["id"].')" class="btn-cart"><i class="fal fa-shopping-cart cart"></i></a>
					</figure>';
			}
			echo $dados;
		}
}
}
