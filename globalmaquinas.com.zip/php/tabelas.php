<?php
session_start();
require("class/conexao.php");
$conexao = new CONEXAO();
$conexao = $conexao->conectar();
$dados ="";

if($_GET){
	
	//Exibição do producto na tabela do cliente que estão no carrinho
	if(isset($_SESSION["id"])){
		if(isset($_GET["cart"]) && $_GET["cart"] == "exibir-p"){
			$sql = "SELECT * FROM carrinho WHERE id_user = :idUser ORDER BY id DESC";
			$stmt = $conexao->prepare($sql);
			$stmt->bindValue(":idUser", $_SESSION["id"]);
			$stmt->execute();
			
			foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
			   $dados .=' <tr>
				  <td><a href="#" class="fas fa-trash-alt delete" onclick="remover('. $row["id"] .','. $row["id_user"] .')"></a></td>
				  <td>'. $row["producto"].'</td>
				  <td>'.$row["marca"].'</td>
				  <td>'.number_format($row["preco"], 2, ",", ".").'kz</td>
				  <td> <input type="number" min-length="1" value="'.$row["quantidade"].'" onchange="actualizar('.$row["id"].','. $row["id_user"] .')"> </td>
				</tr>';
			}
			echo $dados;
		}
	}
	
	
	
	//exibição dos productos na tabela do admin
	if(isset($_GET["admin"]) && $_GET["admin"]=="admin"){
		$sql = "SELECT * FROM producto ORDER BY id DESC LIMIT 25";
		$stmt = $conexao->prepare($sql);
		$stmt->execute();
		

		foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
			
         $dados .='<tr>
					  <td>'.$row["producto"].'</td>
					  <td>'.$row["marca"].'</td>
					  <td>'.number_format($row["preco"], 2, ",", ".").'kz </td>
					  <td>'.$row["quantidade"].'</td>
					  <td>'.$row["descricao"].'</td>
					  <td>
						<ul>
						  <li><a href="#" class="fas fa-trash-alt delete" onclick="apagar('.$row["id"].')"></a></li>
						  <li><a href="update.php?id='.$row["id"].'" class="fas fa-edit edit"></a></li>
						</ul>
					  </td>
					</tr>';
		}
		echo $dados;
	}
	//exibição de clientes na tabela
	if(isset($_GET["cliente"]) && $_GET["cliente"] == "cliente"){
		$sql = "SELECT * FROM user ORDER BY id DESC LIMIT 25";
		$stmt = $conexao->prepare($sql);
		$stmt->execute();
		
		foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
			if($row["nivel_acesso"] == "Admin"){
				continue;
			}
         $dados .=' <tr>
			<td>'.$row["p_nome"] .'</td>
			<td>'. $row["s_nome"] .'</td>
			<td> '.$row["email"] .'</td>
		 </tr>';
		}
		echo $dados;
	}


	//exibição de compras dos clientes na tabela
	if(isset($_GET["compra"]) && $_GET["compra"] == "compra"){
		$sql = "SELECT * FROM compra ORDER BY id DESC LIMIT 25";
		$stmt = $conexao->prepare($sql);
		$stmt->execute();
		
		foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
         $dados .='<tr class="compra">
		 <td>'.$row["email_cliente"] .'</td>
		 <td>'.$row["endereco"] .' </td>
		 <td> '.$row["producto"].' </td>
		 <td>'.$row["banco_pagamento"] .' </td>
		 <td>'.number_format($row["pagamento"], 2, ",", ".").'Kz</td>
		 <td>'.$row["data"].' </td>
		  <td><b><a href="#" class="'.($row["entrega"] == "Realizada"? "realizada": "").'" onclick="realizar('.$row["id"].')">'.$row["entrega"].'</a></b></td>
	   </tr>';
		
		}
		echo $dados;
	}
}else {
	header("location:products.php");
}



		
