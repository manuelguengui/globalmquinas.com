<?php
require("class/conexao.php");
require("class/admin.php");
$conexao = new CONEXAO();
$crud = new ADMIN($conexao);
$dados="";

if($_GET){
	if(isset($_GET["edit"])){
		$crud->__set("id", $_GET["edit"]);
		echo "actualizar";
		if($crud->actualizar() == true){
			$producto = $crud->__get("producto");
			$marca = $crud->__get("marca");
			$preco = $crud->__get("preco");
			$dscr = $crud->__get("descricao");
			$img = $crud->__get("imagem");
			$qtd = $crud->__get("quantidade");
			
			
		}
	}
	
	if(isset($_GET["apagar"])){
		$crud->__set("id", $_GET["apagar"]);
	
		if($crud->apagar() == true){
			echo "apagar";
		}
	}
	if(isset($_GET["realizar"])){
		$crud->__set("id", $_GET["realizar"]);
	
		if($crud->realizar() == true){
			echo "realizar";
		}
	}
	
}

if($_POST){

	//pesquisar productos
	if(isset($_POST["searchproducto"])){
		$sql = " SELECT * FROM producto WHERE producto LIKE '%{$_POST["searchproducto"]}%' ORDER BY id DESC";
		$stmt = $conexao->conectar()->prepare($sql);
		$stmt->execute();
		
		
		foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
         $dados .=' <tr>
					  <td>'.$row["producto"].'</td>
					  <td>'.$row["marca"].'</td>
					  <td>'.number_format($row["preco"], 2, ",", ".").'kz </td>
					  <td>'.$row["quantidade"].'</td>
					  <td>'.$row["descricao"].'</td>
					  <td>
						<ul>
						  <li><a href="#" class="fas fa-trash-alt delete" onclick="apagar('.$row["id"].')"></a></li>
						  <li><a href="update.php?id='.$row["id"].'" class="fas fa-edit edit"></a></li>
						</ul>
					  </td>
					</tr>';
		}
		echo $dados;
	}
	
	//pesquisar compra efectuada pro um cliente
	if(isset($_POST["searchCompra"])){
		$sql = " SELECT * FROM compra WHERE email_cliente LIKE '%{$_POST["searchCompra"]}%' ORDER BY id DESC";
		$stmt = $conexao->conectar()->prepare($sql);
		$stmt->execute();
		
		
		foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
         $dados .=' <tr class="compra">
		 <td>'.$row["email_cliente"] .'</td>
		 <td>'.$row["endereco"] .' </td>
		 <td> '.$row["producto"].' </td>
		 <td>'.$row["banco_pagamento"] .' </td>
		 <td>'.number_format($row["pagamento"], 2, ",", ".").'Kz</td>
		 <td>'.$row["data"].' </td>
		 <td><b><a href="#" class="'.($row["entrega"] == "Realizada"? "realizada": "").'" onclick="realizar('.$row["id"].')">'.$row["entrega"].'</a></b></td>
	   </tr>';
		}
		echo $dados;
	}
	//pesquisar clientes na tabela
	if(isset($_POST["searchcliente"])){
		$sql = " SELECT * FROM user WHERE p_nome LIKE '%{$_POST["searchcliente"]}%' OR email LIKE '%{$_POST["searchcliente"]}%' ORDER BY id DESC";
		$stmt = $conexao->conectar()->prepare($sql);
		$stmt->execute();
		
		
		foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row){
			if($row["nivel_acesso"] == "Admin"){
				continue;
			}
         $dados .=' <tr>
			<td>'.$row["p_nome"] .'</td>
			<td>'. $row["s_nome"] .'</td>
			<td> '.$row["email"] .'</td>
		 </tr>';
		}
		echo $dados;
	}

	if(isset($_POST["id"])){

		$crud->__set("id", (int)$_POST["id"]);
		$crud->__set("producto", $_POST["producto"]);
		$crud->__set("marca", $_POST["marca"]);
		$crud->__set("preco", (int)$_POST["preco"]);
		$crud->__set("quantidade", (int)$_POST["qtd"]);
		$crud->__set("descricao", $_POST["dscr"]);

		if($crud->actualizar() == "Sucesso"){
			echo "Sucesso";
		}else {
			echo "Algo ocorreu mal";
		}
		
	}

}
?>