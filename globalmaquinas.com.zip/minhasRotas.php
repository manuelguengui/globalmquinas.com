<?php
session_start();
require("php/class/conexao.php");
$conexao = new CONEXAO();
$conexao = $conexao->conectar();
if(!(isset($_SESSION["id"]) && ($_SESSION["nivelAcesso"]!="Admin"))){
    header("location:login.php");
}
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de todas as Compras</title>
    <link rel="stylesheet" href="css/relatorio.css">
</head>

<body>

    <main id="factura">
        <header>
            <h1><a href="cart.php"><img src="img/logo.png" width="250"></a></h1>
        </header>
        <br>
        <div class="column-1">
            <section class="info-empresa">
                <strong>GLOBALMÁQUINAS-EQUIPAMENTO INDUSTRIAIS, LDA</strong>
                <P>Contribuinte N.°: 547247073</P>
                <p>Rua do Dream Space, Kikuxi-Viana-Luanda</p>
                <p>Telef: +244 942 520 043 Fax +244 945 166 741</p>
                <p>Capital Social 1 950 000,00 AKZ</p>
                <P>Cons. Reg. Com. 2°SECÇÃOGUICHEUNICO</P>
                <P>Matricula N.° 3355-131018</P>
                <p>globalmaquinas6@gmail.com</p>
                <p>www.globalmaquinas.com</p>
            </section>
            <section class="cliente">
                <?php
                $sql = "SELECT * FROM user WHERE id = :userId";
                $stmt = $conexao->prepare($sql);
                $stmt->bindValue(":userId", (int)$_SESSION["id"]);
                $stmt->execute();

                $row = $stmt->fetch();
                $row["p_nome"];



                ?>
                <p>Exmo.(s) Sr.(s)</p>
                <p class="nome"><?= $row["p_nome"] . " " . $row["s_nome"] ?></p>
                <p>Endereço cliente</p>
            </section>
        </div>
        <h4>Guia de Remessa GR GT. data</h4>

        <div class="column-2">
            <!-- primeira tabela de informação -->
            <div class="column-2-1">
                <table class="first-table tabela">
                    <tr>
                        <th>V/N.°Contrib</th>
                        <th>Requisição</th>
                        <th>Moeda</th>
                        <th>Câmbio</th>
                        <th>Data</th>
                    </tr>
                    <tr>
                        <td>00796990BE036</td>
                        <td></td>
                        <td>AKZ</td>
                        <td>1,00</td>
                        <td><?= date("d-m-Y") ?></td>
                    </tr>
                </table>
                <!-- segunda tabeta de informação -->
                <table class="second-table tabela">
                    <tr>
                        <th>Desc. cli</th>
                        <th>Desc.Fin</th>
                        <th>Vencimento</th>
                    </tr>
                    <tr>
                        <td>0,00</td>
                        <td>0,00</td>
                        <td><?= date("d-m-Y") ?></td>
                        
                    </tr>
                </table>
            </div>
            <!-- tabela de dados de compras -->
            <table class="third-table tabela">
                <tr>
                    <th>Data</th>
                    <th class="descricao">Descrição</th>
                    <th>IVA</th>
                    <th>Total Pagamento</th>
                    <th>BCondição de Pagamento</th>
                    
                </tr>
                <?php
                $sql2 = "SELECT * FROM compra WHERE id_user=:userId ORDER BY data DESC";
                $stmt = $conexao->prepare($sql2);
                $stmt->bindValue(":userId", (int)$_SESSION["id"]);
                $stmt->execute();
                foreach ($stmt->fetchAll() as $row) {
	
				 
                ?>
                    <tr>
                        <td><?= $row["data"] ?></td>
                        <td><?= $row["producto"] ?></td>
                        <td>14,00</td>
                        <td><?= number_format($row["pagamento"], 2, ",", ".")."Kz" ?></td>
                        <td><?= $row["banco_pagamento"] ?></td>
                        
                    </tr>
                <?php } ?>
            </table>
        </div>
        <script>
            window.print();
        </script>


    </main>
</body>

</html>