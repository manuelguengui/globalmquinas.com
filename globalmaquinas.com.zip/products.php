<?php include_once("hf/header.php");


 ?>

<!-- fim header -->

<main>

  <form  id="search">
    <input type="search" name="search" id="search-input" placeholder="Pesquisar...">
    <button class=""><i class="fal fa-search"></i></button>
  </form>

  <section id="product1" class="section-p1 section-pro">
    <h2> Global Máquimas</h2>
    <p>Máquinas e Ferramentas Industriais, LDA</p>


    <div class="pro-conteiner">
	
 
    </div>
  </section>
  <script>
	let exibição = setInterval(()=>{
		
		let xml = new XMLHttpRequest();
		xml.open(`get`, `php/productos.php?producto=producto`, true);
			exibição;
		xml.onreadystatechange = () => {
			if(xml.readyState === XMLHttpRequest.DONE && xml.status === 200){
				
				let resposta = xml.response;
				
				document.querySelector(".pro-conteiner").innerHTML=resposta;
		
			}
		}		
			
		xml.send();
	},4000);
	
	
	</script>

  <section class="paginacao">
    <ul>
      <li><a href="#" id="voltar" onclick="voltar()">Voltar</a></li>
      <li><a href="#" id="proxima" onclick="Próxim()">Próxim</a></li>
    </ul>
  </section>
	

	<script>
	let pagina = 1;
		
		// "Paginação" incrementar para proxima pagina
		function Próxim(){
			let xml = new XMLHttpRequest();
					pagina++;
					
					
					xml.open("get", "php/productos.php?paginar="+pagina, true);
					xml.onreadystatechange = ()=>{
						if(xml.status == 200 && xml.readyState == XMLHttpRequest.DONE){
							clearInterval(exibição);
							let resposta = xml.response;
							document.querySelector(".pro-conteiner").innerHTML=resposta;
							
						}
						
					}
					xml.send();	
		}
		
		//"Paginação" decrementar para página anterior
		function voltar(){
			let xml = new XMLHttpRequest();
					pagina--;
					if(pagina < 0){
						pagina = 1;
					}
					xml.open("get", "php/productos.php?paginar="+pagina, true);
					xml.onreadystatechange = ()=>{
						if(xml.status == 200 && xml.readyState == XMLHttpRequest.DONE){
							clearInterval(exibição);
							let resposta = xml.response;
							document.querySelector(".pro-conteiner").innerHTML=resposta;
							
						}
						
					}
					xml.send();	
		}
		
		//pesquisar productos;
			let search = document.querySelector("#search"),
				searchbtn = search.querySelector("#search input");
				search.addEventListener("submit", (e) => {
				e.preventDefault();	
			});

			  searchbtn.addEventListener("keyup", () => {
				let xml = new XMLHttpRequest();
				xml.open("post", "php/productos.php", true);
				xml.onreadystatechange = () => {
				  if (xml.readyState == XMLHttpRequest.DONE && xml.status == 200) {
					clearInterval(exibição);
					let resposta = xml.response;
					document.querySelector(".pro-conteiner").innerHTML=resposta;
				  }
				  
				}

				let formData = new FormData(search);
				xml.send(formData);
			  })
	</script>

  <!-- footer -->
  <?php include_once("hf/footer.php") ?>