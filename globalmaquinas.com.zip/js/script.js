let bar = document.querySelector("header .conteiner-bar .bar");
let times = document.querySelector("header .conteiner-bar .times");


if (bar) {
    bar.addEventListener("click", () => {
        bar.classList.add("disable");
        times.classList.add("active");
        document.querySelector("header .col").classList.add("active")

        if (times) {
            times.addEventListener("click", () => {
                bar.classList.remove("disable");
                times.classList.remove("active");
                document.querySelector("header .col").classList.remove("active")


            })
        }

    })
}

if (document.querySelector(".form-sign .password i")) {
    document.querySelector(".form-sign .password i").addEventListener("click", () => {
        let password = document.querySelector(".form-sign .password .input-feild")
        if (password.type == "password") {
            password.type = "text";
            document.querySelector(".form-sign .password i").classList.add("active");
        } else {
            password.type = "password";
            document.querySelector(".form-sign .password i").classList.remove("active");
        }
    })
}

let insert = document.querySelector(".admin .insert");
if (insert) {
    document.querySelector(".admin .insert").addEventListener("click", (e) => {
        e.preventDefault();
        document.querySelector(".admin-insert > div").classList.add("active");
        let close = document.querySelector(".close > .times");
        document.body.style.background = "grey";

        if (close) {
            close.addEventListener("click", () => {
                document.body.style.background = "whitesmoke";
                document.querySelector(".admin-insert > div").classList.remove("active");
                let = erroMb = document.getElementById("erro-mb");
                let = erroDk = document.getElementById("erro-dk");
                erroDk.classList.remove("active");
                erroDk.innerText = resposta;
                erroMb.classList.remov("active");
                erroMb.innerText = resposta;

            })
        }

    })
}



// 932 007 594 / 929 700 743 / 932 295 489 / 929 700 688